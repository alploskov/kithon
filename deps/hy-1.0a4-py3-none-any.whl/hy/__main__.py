import sys

from hy.cmdline import hy_main

# Running hy as a module (e.g. `python -m hy`)
# is equivalent to running the main `hy` command.

sys.exit(hy_main())
